// Ergonomic option types for this toolkit. These are NOT the raw Baileys
// protobuf shapes -- the builders in ./builders translate these into the
// exact proto.Message.InteractiveMessage.* structures Baileys expects.

export interface InteractiveHeaderOptions {
	title?: string
	subtitle?: string
	imageUrl?: string
	videoUrl?: string
}

export interface QuickReplyButton {
	type: 'quick_reply'
	displayText: string
	id: string
}

export interface CtaUrlButton {
	type: 'cta_url'
	displayText: string
	url: string
	merchantUrl?: string
}

export interface CtaCallButton {
	type: 'cta_call'
	displayText: string
	phoneNumber: string
}

export interface CtaCopyButton {
	type: 'cta_copy'
	displayText: string
	copyCode: string
}

export interface ListRow {
	title: string
	description?: string
	id: string
}

export interface ListSection {
	title: string
	rows: ListRow[]
}

export interface SingleSelectButton {
	type: 'single_select'
	buttonText: string
	sections: ListSection[]
}

export type InteractiveButton =
	| QuickReplyButton
	| CtaUrlButton
	| CtaCallButton
	| CtaCopyButton
	| SingleSelectButton

export interface InteractiveMessageOptions {
	body: string
	footer?: string
	header?: InteractiveHeaderOptions
	buttons: InteractiveButton[]
}

export interface CarouselCardOptions {
	title?: string
	imageUrl?: string
	videoUrl?: string
	body: string
	footer?: string
	buttons: InteractiveButton[]
}

export interface CarouselMessageOptions {
	body: string
	footer?: string
	cards: CarouselCardOptions[]
}

/**
 * A "flow" here is a chain of ordinary interactive messages driven by your
 * own handler logic -- see builders/flow.ts for why this is a UX pattern,
 * not an implementation of the official WhatsApp Flows protocol.
 */
export interface FlowStep {
	id: string
	body: string
	footer?: string
	header?: InteractiveHeaderOptions
	buttons: InteractiveButton[]
}

export interface FlowOptions {
	steps: FlowStep[]
}
