import type { WASocket } from 'baileys'

export interface PresencePacingOptions {
	/** ms per character used to estimate a "typing" duration. Default 35 (~28 chars/sec). */
	msPerChar?: number
	/** Hard ceiling on the simulated typing duration, regardless of text length. Default 4000. */
	maxMs?: number
	/** Floor on the simulated typing duration. Default 400. */
	minMs?: number
}

/**
 * Sends a 'composing' presence, waits a duration roughly proportional to
 * the outgoing text length, sends 'paused', then runs `send`.
 *
 * This is standard Baileys presence usage (sock.sendPresenceUpdate) --
 * not a protocol-level trick. It paces automated replies closer to how
 * long a person would actually take to type them, instead of arriving
 * instantly after the trigger message, which is one of the "robotic
 * timing" signals community anti-ban write-ups flag as a risk factor.
 *
 * If your bot already manages presence itself, use that instead of this
 * helper -- don't stack two presence-pacing layers on the same jid.
 */
export async function sendWithPresence<T>(
	sock: WASocket,
	jid: string,
	textForPacing: string,
	send: () => Promise<T>,
	options: PresencePacingOptions = {}
): Promise<T> {
	const msPerChar = options.msPerChar ?? 35
	const maxMs = options.maxMs ?? 4000
	const minMs = options.minMs ?? 400

	const typingMs = Math.min(maxMs, Math.max(minMs, textForPacing.length * msPerChar))

	await sock.sendPresenceUpdate('composing', jid)
	await new Promise(resolve => setTimeout(resolve, typingMs))
	await sock.sendPresenceUpdate('paused', jid)

	return send()
}
