export interface DisconnectClassification {
	code: number | undefined
	name: string
	action: 'reconnect' | 'reauth' | 'stop'
	description: string
}

/**
 * Maps a Baileys DisconnectReason status code to a human-readable
 * classification and a recommended action. Values match baileys' own
 * DisconnectReason enum (see baileys.wiki/docs/api/enumerations/DisconnectReason) --
 * this module takes the raw numeric code rather than importing the enum,
 * so it keeps working across baileys versions/package names without
 * needing a direct dependency on either.
 */
export function classifyDisconnect(code: number | undefined): DisconnectClassification {
	switch (code) {
		case 401:
			return {
				code,
				name: 'loggedOut',
				action: 'reauth',
				description: 'The device was logged out from WhatsApp. Do not auto-reconnect -- a fresh pairing (QR/code) is required.'
			}
		case 403:
			return {
				code,
				name: 'forbidden',
				action: 'stop',
				description: 'WhatsApp rejected the connection as forbidden. This is the strongest single signal of a restriction on this number -- stop sending and investigate before reconnecting, rather than retrying immediately.'
			}
		case 440:
			return {
				code,
				name: 'connectionReplaced',
				action: 'reconnect',
				description: 'Another device/session took over this connection. Reconnect, but check you are not accidentally running two bot instances against the same number.'
			}
		case 428:
			return { code, name: 'connectionClosed', action: 'reconnect', description: 'Normal connection closure. Safe to reconnect.' }
		case 408:
			return { code, name: 'connectionLost', action: 'reconnect', description: 'Network issue or timeout. Reconnect with backoff.' }
		case 500:
			return {
				code,
				name: 'badSession',
				action: 'reauth',
				description: 'Invalid session data. May require clearing local auth state and re-pairing.'
			}
		case 411:
			return { code, name: 'multideviceMismatch', action: 'reauth', description: 'Multi-device protocol mismatch -- re-pairing is likely required.' }
		case 503:
			return { code, name: 'unavailableService', action: 'reconnect', description: 'WhatsApp service temporarily unavailable. Reconnect with backoff.' }
		case 515:
			return {
				code,
				name: 'restartRequired',
				action: 'reconnect',
				description: 'Server requested a restart. Reconnect immediately -- this is expected right after pairing.'
			}
		default:
			return {
				code,
				name: 'unknown',
				action: 'reconnect',
				description: `Unrecognized status code (${code ?? 'none'}). This can happen after a WhatsApp/Baileys protocol change -- reconnect with backoff and log it for investigation; check the WhiskeySockets Discord/baileys.wiki if it recurs.`
			}
	}
}

export type RiskLevel = 'normal' | 'elevated' | 'high'

export interface HealthMonitorOptions {
	/** How many minutes back to look when counting recent disconnect events. Default 30. */
	windowMinutes?: number
	/** forbidden (403) events within the window at/above this count escalate risk to 'high'. Default 1 -- forbidden is rare and serious enough that even one warrants stopping to look. */
	forbiddenThreshold?: number
	/** Any-disconnect count within the window at/above this escalates risk to 'elevated'. Default 5. */
	disconnectThreshold?: number
	/** Called whenever the computed risk level changes, with the classifications currently inside the window. */
	onRiskChange?: (level: RiskLevel, recent: DisconnectClassification[]) => void
}

/**
 * Tracks recent disconnect events and classifies overall account risk.
 * This module never touches the socket or the network itself -- feed it
 * status codes from your own `connection.update` handler:
 *
 *   const health = new HealthMonitor({
 *     onRiskChange: (level) => {
 *       if (level === 'high') queue.pause() // see safety/queue.ts
 *     }
 *   })
 *
 *   sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
 *     if (connection === 'close') {
 *       const statusCode = (lastDisconnect?.error as { output?: { statusCode?: number } } | undefined)?.output?.statusCode
 *       health.recordDisconnect(statusCode)
 *     }
 *   })
 *
 * Risk levels are a heuristic over your own connection history, not a
 * WhatsApp-published signal -- treat 'high' as "stop and look into it",
 * not as a certainty that the number has been restricted.
 */
export class HealthMonitor {
	private readonly windowMs: number
	private readonly forbiddenThreshold: number
	private readonly disconnectThreshold: number
	private readonly onRiskChange?: HealthMonitorOptions['onRiskChange']

	private events: { at: number; classification: DisconnectClassification }[] = []
	private currentLevel: RiskLevel = 'normal'

	constructor(options: HealthMonitorOptions = {}) {
		this.windowMs = (options.windowMinutes ?? 30) * 60_000
		this.forbiddenThreshold = options.forbiddenThreshold ?? 1
		this.disconnectThreshold = options.disconnectThreshold ?? 5
		this.onRiskChange = options.onRiskChange
	}

	/** Record a disconnect's status code. Returns the classification so callers can log it inline. */
	recordDisconnect(statusCode: number | undefined): DisconnectClassification {
		const classification = classifyDisconnect(statusCode)
		this.events.push({ at: Date.now(), classification })
		this.reevaluate()
		return classification
	}

	get riskLevel(): RiskLevel {
		return this.currentLevel
	}

	private prune(): void {
		const cutoff = Date.now() - this.windowMs
		this.events = this.events.filter(e => e.at >= cutoff)
	}

	private reevaluate(): void {
		this.prune()
		const forbiddenCount = this.events.filter(e => e.classification.name === 'forbidden').length
		const total = this.events.length

		let next: RiskLevel = 'normal'
		if (forbiddenCount >= this.forbiddenThreshold) next = 'high'
		else if (total >= this.disconnectThreshold) next = 'elevated'

		if (next !== this.currentLevel) {
			this.currentLevel = next
			this.onRiskChange?.(next, this.events.map(e => e.classification))
		}
	}
}
