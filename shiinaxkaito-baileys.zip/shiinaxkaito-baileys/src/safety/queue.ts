export interface WarmUpOptions {
	/** Messages allowed per day on day 1 of a brand-new number sending through this queue. */
	startPerDay: number
	/** Messages allowed per day once the ramp finishes. */
	fullPerDay: number
	/** How many days the linear ramp from startPerDay to fullPerDay takes. */
	rampDays: number
	/** When the number started sending through this queue. Defaults to the first time the queue actually runs a task. */
	startedAt?: Date
}

export interface MessageQueueOptions {
	/** Minimum delay between two sends, in ms. Default 1200. */
	minDelayMs?: number
	/** Maximum delay between two sends, in ms. Default 3500. */
	maxDelayMs?: number
	/**
	 * Optional cap on sends per rolling 60s window, independent of the
	 * per-send delay above. Unset by default (no extra cap beyond the
	 * min/max delay).
	 */
	maxPerMinute?: number
	/**
	 * Gradually ramps daily send volume for a number that just started
	 * sending through this queue instead of allowing full volume from
	 * message one. This mirrors the "warm-up" pattern documented across
	 * community Baileys anti-ban write-ups for new or long-dormant numbers.
	 * Omit for an established number that already sends at volume.
	 */
	warmUp?: WarmUpOptions
}

interface QueueTask<T> {
	run: () => Promise<T>
	resolve: (value: T) => void
	reject: (err: unknown) => void
}

/**
 * A single-lane, delay-and-jitter outgoing message queue.
 *
 * This is NOT a guarantee against rate-limiting or restriction -- nothing
 * built on an unofficial client can offer that (see the README's
 * "Operating within an unofficial client" section). What it does do is
 * remove the most-cited avoidable cause of restriction in Baileys
 * community reports: many messages sent back-to-back with no pacing, which
 * reads to WhatsApp's abuse heuristics as bulk/blast behavior even when a
 * human operator never intended that.
 *
 * Usage:
 *   const queue = new MessageQueue({ minDelayMs: 1500, maxDelayMs: 4000 })
 *   await queue.add(() => interactive.sendInteractive(jid, options))
 *
 * Or pass it straight to InteractiveClient so sendInteractive/sendCarousel
 * route through it automatically -- see src/client.ts.
 */
export class MessageQueue {
	private readonly minDelayMs: number
	private readonly maxDelayMs: number
	private readonly maxPerMinute?: number
	private readonly warmUp?: WarmUpOptions
	private warmUpStartedAt?: Date

	private tasks: QueueTask<unknown>[] = []
	private processing = false
	private paused = false
	private sendTimestamps: number[] = []
	private dailySendCount = 0
	private dailyCountResetAt = MessageQueue.startOfDay(Date.now())

	constructor(options: MessageQueueOptions = {}) {
		this.minDelayMs = options.minDelayMs ?? 1200
		this.maxDelayMs = options.maxDelayMs ?? 3500
		this.maxPerMinute = options.maxPerMinute
		this.warmUp = options.warmUp
	}

	/** Adds a send to the queue. Resolves/rejects when that specific send finishes -- callers can still await individual sends. */
	add<T>(run: () => Promise<T>): Promise<T> {
		return new Promise<T>((resolve, reject) => {
			this.tasks.push({ run, resolve, reject } as QueueTask<unknown>)
			void this.process()
		})
	}

	/** Stops new sends from going out until resume() is called. A send already in flight still finishes. */
	pause(): void {
		this.paused = true
	}

	resume(): void {
		this.paused = false
		void this.process()
	}

	get isPaused(): boolean {
		return this.paused
	}

	/** Number of sends still waiting in line. */
	get pending(): number {
		return this.tasks.length
	}

	private static startOfDay(ts: number): number {
		const d = new Date(ts)
		d.setHours(0, 0, 0, 0)
		return d.getTime()
	}

	private dailyLimit(): number | undefined {
		if (!this.warmUp) return undefined
		if (!this.warmUpStartedAt) this.warmUpStartedAt = this.warmUp.startedAt ?? new Date()

		const daysSinceStart = Math.floor((Date.now() - this.warmUpStartedAt.getTime()) / 86_400_000)
		if (daysSinceStart >= this.warmUp.rampDays) return this.warmUp.fullPerDay

		const progress = daysSinceStart / this.warmUp.rampDays
		const ramped = this.warmUp.startPerDay + (this.warmUp.fullPerDay - this.warmUp.startPerDay) * progress
		return Math.round(ramped)
	}

	private async process(): Promise<void> {
		if (this.processing) return
		this.processing = true

		try {
			while (this.tasks.length > 0 && !this.paused) {
				const now = Date.now()

				if (now >= this.dailyCountResetAt + 86_400_000) {
					this.dailyCountResetAt = MessageQueue.startOfDay(now)
					this.dailySendCount = 0
				}

				const limit = this.dailyLimit()
				if (limit !== undefined && this.dailySendCount >= limit) {
					// Warm-up cap reached for today -- stop instead of silently
					// dropping tasks. They stay queued and resume once the daily
					// counter rolls over (or after a manual resume()).
					break
				}

				if (this.maxPerMinute) {
					this.sendTimestamps = this.sendTimestamps.filter(t => now - t < 60_000)
					if (this.sendTimestamps.length >= this.maxPerMinute) {
						await delay(60_000 - (now - this.sendTimestamps[0]))
						continue
					}
				}

				const task = this.tasks.shift()
				if (!task) break

				try {
					const result = await task.run()
					task.resolve(result)
				} catch (err) {
					task.reject(err)
				}

				this.sendTimestamps.push(Date.now())
				this.dailySendCount++

				if (this.tasks.length > 0 && !this.paused) {
					await delay(jitterDelay(this.minDelayMs, this.maxDelayMs))
				}
			}
		} finally {
			this.processing = false
		}
	}
}

function delay(ms: number): Promise<void> {
	return new Promise(resolve => setTimeout(resolve, Math.max(0, ms)))
}

/**
 * Randomized delay between min and max, weighted toward the middle rather
 * than uniform -- the average of two independent Math.random() calls
 * approximates a triangular distribution, which avoids the perfectly flat
 * timing profile of `Math.random() * (max - min)` without pulling in a
 * statistics dependency.
 */
function jitterDelay(min: number, max: number): number {
	const t = (Math.random() + Math.random()) / 2
	return Math.round(min + t * (max - min))
}
