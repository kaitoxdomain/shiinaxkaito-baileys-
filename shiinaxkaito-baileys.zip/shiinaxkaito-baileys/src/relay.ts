import {
	generateMessageIDV2,
	generateWAMessageFromContent,
	isJidGroup,
	proto,
	type WAMessage,
	type WASocket
} from 'baileys'

export interface RelayInteractiveOptions {
	quoted?: WAMessage
}

/**
 * Sends already-built interactive/carousel content (the proto.IMessage
 * objects produced by ./builders) through the socket's own relayMessage,
 * attaching the `bot` / biz_bot additionalNode that mainline Baileys does
 * not attach on its own for these message types.
 *
 * WHY NOT JUST sock.sendMessage(jid, content)?
 * As of the Baileys version this toolkit was built and verified against
 * (7.0.0-rc14), sendMessage's internal additionalNodes handling only
 * special-cases delete/edit/pin/poll/event content -- there's no branch
 * for interactiveMessage. That means the node WhatsApp's server needs in
 * order to render buttons/lists/carousels for a sender that isn't a
 * verified Business API partner never gets attached, and the message can
 * arrive on the recipient's device with nothing visible. Calling
 * relayMessage directly gives access to the additionalNodes hook that
 * sendMessage doesn't expose for this case.
 *
 * This is the same workaround several community Baileys add-ons use --
 * it isn't a secret technique, but it also isn't documented by
 * WhiskeySockets, and it was reverse-engineered from client behavior
 * rather than from any WhatsApp spec. Treat the `biz_bot` node as "known
 * to work as of mid-2026," not a stable contract: if buttons or carousels
 * stop rendering after a Baileys or WhatsApp update, this is the first
 * place to check, and the WhiskeySockets Discord / baileys.wiki is the
 * best place to look for what changed.
 *
 * The biz_bot node is only added for 1:1 chats -- that matches the
 * pattern observed in current community implementations. Group-chat
 * behavior for interactive messages is less consistently documented;
 * if you need this in groups, verify it renders correctly on a real
 * device before shipping it.
 */
export async function relayInteractiveMessage(
	sock: WASocket,
	jid: string,
	content: proto.IMessage,
	options: RelayInteractiveOptions = {}
): Promise<WAMessage> {
	if (!sock.user?.id) {
		throw new Error(
			'relayInteractiveMessage: sock.user is not set yet -- call this after the socket has finished connecting (after the "connection.update" event reports connection: "open").'
		)
	}

	const messageId = generateMessageIDV2(sock.user.id)

	const fullMessage = generateWAMessageFromContent(jid, content, {
		userJid: sock.user.id,
		quoted: options.quoted,
		messageId
	})

	if (!fullMessage.message) {
		throw new Error('relayInteractiveMessage: generateWAMessageFromContent did not produce a message body.')
	}

	const additionalNodes = isJidGroup(jid) ? [] : [{ tag: 'bot', attrs: { biz_bot: '1' } }]

	await sock.relayMessage(jid, fullMessage.message, {
		messageId,
		additionalNodes
	})

	return fullMessage
}
