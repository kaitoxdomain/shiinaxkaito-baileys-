import type { WAMessage, WASocket } from 'baileys'
import { buildCarouselMessage } from './builders/carousel.js'
import { buildInteractiveMessage } from './builders/interactive.js'
import { relayInteractiveMessage, type RelayInteractiveOptions } from './relay.js'
import type { MessageQueue } from './safety/queue.js'
import type { CarouselMessageOptions, InteractiveMessageOptions } from './types.js'

export interface InteractiveClientOptions {
	/**
	 * Optional MessageQueue (see src/safety/queue.ts) to route sends
	 * through. When set, sendInteractive/sendCarousel are queued (paced,
	 * and optionally rate-capped / warmed-up) instead of firing
	 * immediately. Omit for the previous, unqueued behavior.
	 */
	queue?: MessageQueue
}

/**
 * Thin ergonomic wrapper around an existing Baileys WASocket. This does
 * NOT create or manage the connection -- pass in a socket you already
 * built with makeWASocket() from `baileys`, same as any other Baileys
 * send call.
 */
export class InteractiveClient {
	private readonly queue?: MessageQueue

	constructor(private readonly sock: WASocket, options: InteractiveClientOptions = {}) {
		this.queue = options.queue
	}

	private get mediaOptions() {
		return { upload: this.sock.waUploadToServer }
	}

	private runOrQueue<T>(task: () => Promise<T>): Promise<T> {
		return this.queue ? this.queue.add(task) : task()
	}

	async sendInteractive(
		jid: string,
		options: InteractiveMessageOptions,
		relayOptions?: RelayInteractiveOptions
	): Promise<WAMessage> {
		return this.runOrQueue(async () => {
			const content = await buildInteractiveMessage(options, this.mediaOptions)
			return relayInteractiveMessage(this.sock, jid, content, relayOptions)
		})
	}

	async sendCarousel(
		jid: string,
		options: CarouselMessageOptions,
		relayOptions?: RelayInteractiveOptions
	): Promise<WAMessage> {
		return this.runOrQueue(async () => {
			const content = await buildCarouselMessage(options, this.mediaOptions)
			return relayInteractiveMessage(this.sock, jid, content, relayOptions)
		})
	}
}
