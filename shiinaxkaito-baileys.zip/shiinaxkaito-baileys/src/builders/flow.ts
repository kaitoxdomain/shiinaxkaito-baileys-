import type { FlowOptions, FlowStep } from '../types.js'

/**
 * READ THIS BEFORE WIRING UP "NATIVE FLOW" -- IT'S A LIMITATION, NOT A BUG.
 *
 * In the official WhatsApp Business Platform, a "Flow" is a multi-screen
 * form defined in a Flow JSON, hosted by Meta, and exchanged with the
 * client over an encrypted data channel tied to a verified WhatsApp
 * Business Account and a real flow_id Meta issued for it. None of that
 * infrastructure exists for an unofficial socket client: there's no
 * Meta-hosted flow to reference and no key exchange to piggyback on.
 * Sending a raw nativeFlowMessage button with name: "flow" and a made-up
 * flow_id will not open a real Flow screen on the recipient's device --
 * at best it does nothing, at worst it renders as a broken button.
 *
 * What CAN be built on top of Baileys is a "pseudo-flow": a sequence of
 * ordinary interactive messages (buttons / lists), chained together by
 * your own message-handler logic, so a multi-step interaction *feels*
 * like a flow even though each step is a separate message the recipient
 * replies to individually. That's what this module gives you -- a small
 * session helper for tracking where a user is in that sequence. It is
 * not an implementation of the official Flows protocol, and it won't get
 * you the Flow Builder UI, built-in screen validation, or the encrypted
 * payload format. If you need genuine multi-screen Flows, that requires
 * an official WhatsApp Business Platform account.
 */

export interface FlowSession {
	steps: FlowStep[]
	currentIndex: number
}

export function startFlow(options: FlowOptions): FlowSession {
	return { steps: options.steps, currentIndex: 0 }
}

export function currentFlowStep(session: FlowSession): FlowStep | undefined {
	return session.steps[session.currentIndex]
}

/** Call this from your message handler once a reply matches the expected button/row id for the current step. */
export function advanceFlow(session: FlowSession): FlowSession {
	return { ...session, currentIndex: Math.min(session.currentIndex + 1, session.steps.length) }
}

export function isFlowComplete(session: FlowSession): boolean {
	return session.currentIndex >= session.steps.length
}
