import { prepareWAMessageMedia, proto } from 'baileys'
import type { InteractiveButton, InteractiveHeaderOptions, InteractiveMessageOptions } from '../types.js'

type MediaOptions = Parameters<typeof prepareWAMessageMedia>[1]

/**
 * Converts one ergonomic InteractiveButton into the raw
 * { name, buttonParamsJson } shape the WhatsApp client reads.
 *
 * These `name` values (quick_reply, cta_url, cta_call, cta_copy,
 * single_select) match what's currently known to render correctly across
 * Baileys-based interactive-message implementations. WhatsApp doesn't
 * publish this list -- if a button silently fails to render on a real
 * device, that's the first thing to re-check against current community
 * reports (baileys.wiki, the WhiskeySockets Discord), since these names
 * and their expected JSON shape can shift without notice.
 */
export function toNativeFlowButton(
	button: InteractiveButton
): proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton {
	switch (button.type) {
		case 'quick_reply':
			return {
				name: 'quick_reply',
				buttonParamsJson: JSON.stringify({
					display_text: button.displayText,
					id: button.id
				})
			}
		case 'cta_url':
			return {
				name: 'cta_url',
				buttonParamsJson: JSON.stringify({
					display_text: button.displayText,
					url: button.url,
					merchant_url: button.merchantUrl ?? button.url
				})
			}
		case 'cta_call':
			return {
				name: 'cta_call',
				buttonParamsJson: JSON.stringify({
					display_text: button.displayText,
					phone_number: button.phoneNumber
				})
			}
		case 'cta_copy':
			return {
				name: 'cta_copy',
				buttonParamsJson: JSON.stringify({
					display_text: button.displayText,
					copy_code: button.copyCode
				})
			}
		case 'single_select':
			return {
				name: 'single_select',
				buttonParamsJson: JSON.stringify({
					title: button.buttonText,
					sections: button.sections.map(section => ({
						title: section.title,
						rows: section.rows.map(row => ({
							title: row.title,
							description: row.description ?? '',
							id: row.id
						}))
					}))
				})
			}
	}
}

export async function buildInteractiveHeader(
	header: InteractiveHeaderOptions | undefined,
	mediaOptions: MediaOptions
): Promise<proto.Message.InteractiveMessage.IHeader | undefined> {
	if (!header) return undefined

	const base: proto.Message.InteractiveMessage.IHeader = {
		title: header.title,
		subtitle: header.subtitle,
		hasMediaAttachment: Boolean(header.imageUrl || header.videoUrl)
	}

	if (header.imageUrl) {
		const media = await prepareWAMessageMedia({ image: { url: header.imageUrl } }, mediaOptions)
		return { ...base, imageMessage: media.imageMessage }
	}

	if (header.videoUrl) {
		const media = await prepareWAMessageMedia({ video: { url: header.videoUrl } }, mediaOptions)
		return { ...base, videoMessage: media.videoMessage }
	}

	return base
}

/**
 * Builds a raw interactiveMessage content object. This only builds the
 * message content -- it does not send anything. Pass the result to
 * relayInteractiveMessage() in ../relay.ts to actually deliver it.
 */
export async function buildInteractiveMessage(
	options: InteractiveMessageOptions,
	mediaOptions: MediaOptions
): Promise<proto.IMessage> {
	const header = await buildInteractiveHeader(options.header, mediaOptions)

	return {
		interactiveMessage: {
			header,
			body: { text: options.body },
			footer: options.footer ? { text: options.footer } : undefined,
			nativeFlowMessage: {
				buttons: options.buttons.map(toNativeFlowButton)
			}
		}
	}
}
