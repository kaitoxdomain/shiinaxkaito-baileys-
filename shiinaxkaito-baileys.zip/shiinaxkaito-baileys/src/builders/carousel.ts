import { prepareWAMessageMedia, proto } from 'baileys'
import type { CarouselCardOptions, CarouselMessageOptions } from '../types.js'
import { toNativeFlowButton } from './interactive.js'

type MediaOptions = Parameters<typeof prepareWAMessageMedia>[1]

async function buildCard(
	card: CarouselCardOptions,
	mediaOptions: MediaOptions
): Promise<proto.Message.IInteractiveMessage> {
	let header: proto.Message.InteractiveMessage.IHeader | undefined

	if (card.imageUrl) {
		const media = await prepareWAMessageMedia({ image: { url: card.imageUrl } }, mediaOptions)
		header = { title: card.title, hasMediaAttachment: true, imageMessage: media.imageMessage }
	} else if (card.videoUrl) {
		const media = await prepareWAMessageMedia({ video: { url: card.videoUrl } }, mediaOptions)
		header = { title: card.title, hasMediaAttachment: true, videoMessage: media.videoMessage }
	} else if (card.title) {
		header = { title: card.title, hasMediaAttachment: false }
	}

	return {
		header,
		body: { text: card.body },
		footer: card.footer ? { text: card.footer } : undefined,
		nativeFlowMessage: {
			buttons: card.buttons.map(toNativeFlowButton)
		}
	}
}

/**
 * Cards are prepared concurrently: each one may involve uploading media,
 * and doing that serially would make a 5-card carousel take roughly 5x as
 * long as it needs to.
 *
 * carouselCardType defaults to HSCROLL_CARDS (the standard swipeable-card
 * layout). ALBUM_IMAGE is a different WhatsApp UI pattern that this
 * toolkit doesn't build a dedicated helper for yet -- pass it in
 * carouselCardType directly if you need it and know the card shape it
 * expects.
 */
export async function buildCarouselMessage(
	options: CarouselMessageOptions,
	mediaOptions: MediaOptions,
	carouselCardType: proto.Message.InteractiveMessage.CarouselMessage.CarouselCardType = proto.Message
		.InteractiveMessage.CarouselMessage.CarouselCardType.HSCROLL_CARDS
): Promise<proto.IMessage> {
	const cards = await Promise.all(options.cards.map(card => buildCard(card, mediaOptions)))

	return {
		interactiveMessage: {
			body: { text: options.body },
			footer: options.footer ? { text: options.footer } : undefined,
			carouselMessage: {
				cards,
				messageVersion: 1,
				carouselCardType
			}
		}
	}
}
