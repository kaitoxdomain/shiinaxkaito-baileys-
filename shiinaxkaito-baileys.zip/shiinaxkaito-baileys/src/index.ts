import { printShiinaXKaitoBanner } from './banner.js'

printShiinaXKaitoBanner()

export { InteractiveClient, type InteractiveClientOptions } from './client.js'
export { relayInteractiveMessage, type RelayInteractiveOptions } from './relay.js'

export { buildInteractiveMessage, toNativeFlowButton } from './builders/interactive.js'
export { buildCarouselMessage } from './builders/carousel.js'
export { advanceFlow, currentFlowStep, isFlowComplete, startFlow, type FlowSession } from './builders/flow.js'

// Protocol-drift awareness -- see "Staying in sync with WhatsApp's protocol" in the README.
export {
	TESTED_BAILEYS_VERSION,
	checkInstalledBaileysVersion,
	warnIfBaileysVersionDrifted,
	checkWaWebVersionDrift,
	type InstalledVersionReport,
	type WaWebVersionDrift
} from './compat/version.js'

// Ban-risk-reduction helpers -- see "Reducing ban risk" in the README.
export { MessageQueue, type MessageQueueOptions, type WarmUpOptions } from './safety/queue.js'
export {
	HealthMonitor,
	classifyDisconnect,
	type DisconnectClassification,
	type HealthMonitorOptions,
	type RiskLevel
} from './safety/health.js'
export { sendWithPresence, type PresencePacingOptions } from './safety/presence.js'

export type {
	CarouselCardOptions,
	CarouselMessageOptions,
	CtaCallButton,
	CtaCopyButton,
	CtaUrlButton,
	FlowOptions,
	FlowStep,
	InteractiveButton,
	InteractiveHeaderOptions,
	InteractiveMessageOptions,
	ListRow,
	ListSection,
	QuickReplyButton,
	SingleSelectButton
} from './types.js'
