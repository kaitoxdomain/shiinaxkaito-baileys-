import { createRequire } from 'node:module'

/**
 * The baileys version relay.ts's biz_bot workaround (see ../relay.ts) was
 * last verified against on a real device. Bump this after manually
 * re-testing relay.ts against a new baileys release.
 */
export const TESTED_BAILEYS_VERSION = '7.0.0-rc14'

export interface InstalledVersionReport {
	installed: string | null
	tested: string
	matchesTested: boolean
	message: string
}

/**
 * Reads the *installed* baileys package.json version from node_modules and
 * compares it to TESTED_BAILEYS_VERSION. This is a local disk read only --
 * no network call -- so it's safe to run on every startup.
 *
 * A mismatch doesn't prove anything is broken. It means the relay.ts
 * workaround hasn't been manually re-verified against whatever baileys
 * version you currently have installed. The interactiveMessage /
 * carouselMessage relay path is reverse-engineered, not a documented API
 * (see the README section "The interactive-message gap this toolkit
 * patches"), which makes it the most likely thing to silently break after
 * a baileys upgrade.
 */
export function checkInstalledBaileysVersion(): InstalledVersionReport {
	const require = createRequire(import.meta.url)
	let installed: string | null = null

	for (const pkg of ['baileys/package.json', '@whiskeysockets/baileys/package.json']) {
		try {
			installed = (require(pkg) as { version: string }).version
			break
		} catch {
			// try the next known package name for this dependency
		}
	}

	if (!installed) {
		return {
			installed: null,
			tested: TESTED_BAILEYS_VERSION,
			matchesTested: false,
			message: 'Could not find an installed baileys (or @whiskeysockets/baileys) package -- is it installed?'
		}
	}

	const matchesTested = installed === TESTED_BAILEYS_VERSION
	return {
		installed,
		tested: TESTED_BAILEYS_VERSION,
		matchesTested,
		message: matchesTested
			? `baileys@${installed} matches the version relay.ts was last verified against.`
			: `baileys@${installed} is installed; relay.ts was last verified against baileys@${TESTED_BAILEYS_VERSION}. If buttons or carousels stop rendering, src/relay.ts is the first place to check -- see the WhiskeySockets Discord (whiskey.so/discord) or baileys.wiki for what changed.`
	}
}

/**
 * Convenience wrapper: runs checkInstalledBaileysVersion() and console.warns
 * when it doesn't match. Never throws and never blocks startup -- a version
 * mismatch is a "go check relay.ts" signal, not proof of a broken build.
 * Call this once near startup, after your imports resolve.
 */
export function warnIfBaileysVersionDrifted(): InstalledVersionReport {
	const report = checkInstalledBaileysVersion()
	if (!report.matchesTested) {
		console.warn(`[shiinaxkaito-baileys] ${report.message}`)
	}
	return report
}

export interface WaWebVersionDrift {
	pinned: string
	latest: string
	/** True when the version your socket is pinned to still matches what WhatsApp currently serves. */
	pinnedIsCurrent: boolean
}

/**
 * Compares the WhatsApp Web version your socket is pinned to (whatever you
 * pass as `version` in makeWASocket()) against what baileys' own
 * fetchLatestWaWebVersion() currently reports live from WhatsApp. This
 * makes a network call -- call it from a manual/admin trigger or a
 * periodic job (e.g. once a day), not on every connect.
 *
 * Per Baileys' own configuration guidance, don't auto-apply "latest" on
 * every connect just because it's available: jumping to a version your
 * relay logic and protobufs haven't been checked against can break things
 * worse than staying pinned. Use this to get notified a check is worth
 * doing, not to auto-upgrade unattended.
 *
 * @param fetchLatestWaWebVersion pass the function of the same name
 *   imported from 'baileys' -- this module doesn't import baileys directly
 *   so it keeps working regardless of which baileys package name
 *   (`baileys` vs `@whiskeysockets/baileys`) your project depends on.
 * @param pinnedVersion the WAVersion tuple your socket is currently
 *   configured with.
 */
export async function checkWaWebVersionDrift(
	fetchLatestWaWebVersion: (options?: unknown) => Promise<{ version: [number, number, number] }>,
	pinnedVersion: [number, number, number]
): Promise<WaWebVersionDrift> {
	const { version: latest } = await fetchLatestWaWebVersion()
	const pinned = pinnedVersion.join('.')
	const latestStr = latest.join('.')

	return {
		pinned,
		latest: latestStr,
		pinnedIsCurrent: pinned === latestStr
	}
}
