/**
 * Promo banner -- prints once, automatically, whenever this package is
 * imported by a consuming project (see the call at the top of index.ts).
 * This is a deliberate import-time side effect: unusual for a library in
 * general, but that's the point here -- it's a branding/promo banner, not
 * something meant to be opt-in.
 *
 * Update STORE_URL / CONTACT_NUMBER below if either ever changes -- both
 * are only defined once and reused in the banner output.
 */

const ART_LINES = [
	'███████╗██╗  ██╗██╗██╗███╗   ██╗ █████╗ ██╗  ██╗██╗  ██╗ █████╗ ██╗████████╗ ██████╗',
	'██╔════╝██║  ██║██║██║████╗  ██║██╔══██╗╚██╗██╔╝██║ ██╔╝██╔══██╗██║╚══██╔══╝██╔═══██╗',
	'███████╗███████║██║██║██╔██╗ ██║███████║ ╚███╔╝ █████╔╝ ███████║██║   ██║   ██║   ██║',
	'╚════██║██╔══██║██║██║██║╚██╗██║██╔══██║ ██╔██╗ ██╔═██╗ ██╔══██║██║   ██║   ██║   ██║',
	'███████║██║  ██║██║██║██║ ╚████║██║  ██║██╔╝ ██╗██║  ██╗██║  ██║██║   ██║   ╚██████╔╝',
	'╚══════╝╚═╝  ╚═╝╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝    ╚═════╝'
]

const STORE_URL = 'https://shiina-md-store.netlify.app/'
const CONTACT_NUMBER = '6285783790408'

const RULE = '─'.repeat(Math.max(...ART_LINES.map(line => line.length)))

/** Wraps `text` in the given SGR code(s) (e.g. '96;1' = bold bright cyan), reset afterward. */
function sgr(code: string, text: string): string {
	return `\x1b[${code}m${text}\x1b[0m`
}

export function printShiinaXKaitoBanner(): void {
	const out = [
		'',
		...ART_LINES.map(line => sgr('96;1', line)),
		sgr('2', RULE),
		`  Sewa Bot Hanya Ke: ${sgr('92;1;4', STORE_URL)}`,
		`  Ingin Bertanya Hal-hal lainnya? Hubungi: ${sgr('93;1', CONTACT_NUMBER)}`,
		sgr('2', RULE),
		''
	]
	console.log(out.join('\n'))
}
