import makeWASocket, { useMultiFileAuthState } from 'baileys'
import qrcodeTerminal from 'qrcode-terminal'
import {
	InteractiveClient,
	MessageQueue,
	HealthMonitor,
	sendWithPresence,
	warnIfBaileysVersionDrifted
} from '../src/index.js'

async function main() {
	// --- Protocol-drift awareness ---
	// Local-only, no network call: tells you whether the installed baileys
	// version matches what relay.ts was last verified against. See
	// "Staying in sync with WhatsApp's protocol" in the README for the
	// network-checking counterpart (checkWaWebVersionDrift), which is meant
	// to be run periodically (e.g. a daily cron / admin command), not here.
	warnIfBaileysVersionDrifted()

	const { state, saveCreds } = await useMultiFileAuthState('auth')

	// --- Ban-risk reduction: rate-limited queue with a warm-up ramp ---
	// Adjust startPerDay/fullPerDay/rampDays to your own number's history --
	// these numbers are a starting point, not a guarantee (see the README's
	// "Operating within an unofficial client" section).
	const queue = new MessageQueue({
		minDelayMs: 1500,
		maxDelayMs: 4000,
		maxPerMinute: 20,
		warmUp: { startPerDay: 20, fullPerDay: 200, rampDays: 7 }
	})

	// --- Ban-risk reduction: health monitoring off real disconnect codes ---
	const health = new HealthMonitor({
		onRiskChange: (level, recent) => {
			console.warn(`[health] risk level -> ${level}`, recent.map(r => r.name))
			if (level === 'high') {
				// forbidden (403) or repeated disconnects: stop sending and let a
				// human look, rather than retrying into a worse restriction.
				queue.pause()
			}
		}
	})

	// NOTE: printQRInTerminal is deprecated as of the baileys version this
	// toolkit is tested against (7.0.0-rc14) -- it no longer prints anything,
	// only logs one deprecation warning. Render the `qr` field from
	// connection.update yourself instead.
	const sock = makeWASocket({ auth: state })
	sock.ev.on('creds.update', saveCreds)

	sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
		if (qr) {
			qrcodeTerminal.generate(qr, { small: true })
		}
		if (connection === 'close') {
			const statusCode = (lastDisconnect?.error as { output?: { statusCode?: number } } | undefined)?.output
				?.statusCode
			const classification = health.recordDisconnect(statusCode)
			console.log('disconnected:', classification.name, '-', classification.description)
		}
		if (connection === 'open') {
			console.log('connected, socket ready. queue paused?', queue.isPaused)
		}
	})

	// Route all interactive/carousel sends through the queue.
	const interactive = new InteractiveClient(sock, { queue })

	sock.ev.on('messages.upsert', async ({ messages }) => {
		const msg = messages[0]
		if (!msg.message || msg.key.fromMe) return

		const from = msg.key.remoteJid!
		const text = msg.message.conversation ?? msg.message.extendedTextMessage?.text ?? ''

		if (text === '!menu') {
			const body = 'Pilih salah satu menu di bawah ini'

			// Presence pacing + rate-limited queue together: a natural typing
			// pause, then the actual send goes through the same queue as
			// everything else so pacing/warm-up limits still apply.
			await sendWithPresence(sock, from, body, () =>
				interactive.sendInteractive(from, {
					body,
					footer: 'Toko Contoh',
					header: { title: 'Menu Utama' },
					buttons: [
						{ type: 'quick_reply', displayText: 'Cek Stok', id: 'cek_stok' },
						{ type: 'cta_url', displayText: 'Kunjungi Website', url: 'https://example.com' }
					]
				})
			)
		}
	})
}

main().catch(console.error)
