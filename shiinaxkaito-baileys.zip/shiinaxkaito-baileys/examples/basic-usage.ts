import makeWASocket, { useMultiFileAuthState } from 'baileys'
import qrcodeTerminal from 'qrcode-terminal'
import { InteractiveClient, startFlow, currentFlowStep, advanceFlow, isFlowComplete } from '../src/index.js'
import type { FlowSession } from '../src/index.js'

async function main() {
	const { state, saveCreds } = await useMultiFileAuthState('auth')
	// NOTE: makeWASocket's printQRInTerminal option is deprecated as of the
	// baileys version this toolkit is tested against (7.0.0-rc14) -- setting
	// it no longer prints anything, only logs one deprecation warning. Render
	// the `qr` field from connection.update yourself instead (this is also
	// what the deprecation warning itself, and baileys.wiki, now recommend).
	const sock = makeWASocket({ auth: state })
	sock.ev.on('creds.update', saveCreds)

	const interactive = new InteractiveClient(sock)
	const sessions = new Map<string, FlowSession>()

	sock.ev.on('connection.update', ({ connection, qr }) => {
		if (qr) {
			qrcodeTerminal.generate(qr, { small: true })
		}
		if (connection === 'open') {
			console.log('connected, socket ready')
		}
	})

	sock.ev.on('messages.upsert', async ({ messages }) => {
		const msg = messages[0]
		if (!msg.message || msg.key.fromMe) return

		const from = msg.key.remoteJid!
		const text = msg.message.conversation ?? msg.message.extendedTextMessage?.text ?? ''

		// --- Example 1: interactive buttons ---
		if (text === '!menu') {
			await interactive.sendInteractive(from, {
				body: 'Pilih salah satu menu di bawah ini',
				footer: 'Toko Contoh',
				header: { title: 'Menu Utama' },
				buttons: [
					{ type: 'quick_reply', displayText: 'Cek Stok', id: 'cek_stok' },
					{ type: 'cta_url', displayText: 'Kunjungi Website', url: 'https://example.com' },
					{
						type: 'single_select',
						buttonText: 'Lihat Kategori',
						sections: [
							{
								title: 'Kategori',
								rows: [
									{ title: 'Elektronik', id: 'kat_elektronik' },
									{ title: 'Fashion', id: 'kat_fashion' }
								]
							}
						]
					}
				]
			})
		}

		// --- Example 2: carousel ---
		if (text === '!katalog') {
			await interactive.sendCarousel(from, {
				body: 'Produk terbaru minggu ini',
				cards: [
					{
						title: 'Produk A',
						imageUrl: 'https://example.com/produk-a.jpg',
						body: 'Deskripsi produk A',
						buttons: [{ type: 'quick_reply', displayText: 'Pesan', id: 'pesan_a' }]
					},
					{
						title: 'Produk B',
						imageUrl: 'https://example.com/produk-b.jpg',
						body: 'Deskripsi produk B',
						buttons: [{ type: 'quick_reply', displayText: 'Pesan', id: 'pesan_b' }]
					}
				]
			})
		}

		// --- Example 3: pseudo-flow (see builders/flow.ts for what this is and isn't) ---
		if (text === '!daftar') {
			const session = startFlow({
				steps: [
					{ id: 'nama', body: 'Siapa nama lengkap kamu?', buttons: [] },
					{ id: 'alamat', body: 'Alamat pengiriman?', buttons: [] }
				]
			})
			sessions.set(from, session)
			await interactive.sendInteractive(from, { body: currentFlowStep(session)!.body, buttons: [] })
			return
		}

		const session = sessions.get(from)
		if (session && !isFlowComplete(session)) {
			const next = advanceFlow(session)
			sessions.set(from, next)
			const step = currentFlowStep(next)
			if (step) {
				await interactive.sendInteractive(from, { body: step.body, buttons: step.buttons })
			} else {
				await sock.sendMessage(from, { text: 'Selesai, terima kasih!' })
				sessions.delete(from)
			}
		}
	})
}

main().catch(console.error)
